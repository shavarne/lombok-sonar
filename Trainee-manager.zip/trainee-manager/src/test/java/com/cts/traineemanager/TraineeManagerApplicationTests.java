package com.cts.traineemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraineeManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
