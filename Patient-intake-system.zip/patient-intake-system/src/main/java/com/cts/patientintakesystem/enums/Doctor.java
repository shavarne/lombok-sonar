package com.cts.patientintakesystem.enums;

public enum Doctor {
		DENTIST,CARDIALOGIST,AUDIOLOGIST,GYNAECOLOGIST,PAEDIATRICIAN; 
}
